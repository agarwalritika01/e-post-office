<div class="panels-container">
  <div class="panel-wrapper">
  <div class="panel"> <img src="images/deposit.png" width="180" height="180" alt=""/>
      <h1>DEPOSITE </h1>
      <ul>
        <p style="font-size:24px;">By using this facility you can keep your money safe here. It is a place where money can be kept safe and get a good growth on your money.</strong></li>
        <li class="panel-bottom"></li>
      </ul>
    </div>
    
    <div class="panel"> <img src="images/withdraw.jpe" width="180" height="180" alt=""/>
      <h1>WITHDRAW</h1>
      <ul>
        <li class="panel-middle">
        <p style="font-size:24px;">You can withdraw deposited money as and when necessary(based on conditions) and make full use of it</p></li>
        <li class="panel-bottom"></li>
      </ul>
    </div>
    <div class="panel"> <img src="images/payment.jpe" width="180" height="180" alt=""/>
      <h1>BILL PAYMENT</h1>
      <h2>&nbsp;</h2>
      <ul>
        <li class="panel-top"></li>
        <li class="panel-middle">
           <p style="font-size:24px;">Instead of going to post office and paying your bill its easier to pay it online on given due date either from your own account or as directed</p>
        </li>
        <li class="panel-bottom"></li>
      </ul>
    </div>
    <div class="panel"> <img src="images/moneyorder.jpg" width="180" height="180" alt=""/>
      <h1>MONEY ORDER</h1>
      <h2>&nbsp;</h2>
      <ul>
        <li class="panel-top"></li>
        <li class="panel-middle">
         <p style="font-size:24px;">Want  to send  money to someone who does not have an account? Then here's facility to help you. By using money order facility you can send your money to anyone with zero effort.</p>
        </li>
        <li class="panel-bottom"></li>
      </ul>
    </div>
    <div class="panel"> <img src="images/insurance.jpg" width="180" height="180" alt=""/>
      <h1>INSURANCE</h1>
      <h2>&nbsp;</h2>
      <ul>
        <li class="panel-top"></li>
        <li class="panel-middle">
          <p style="font-size:24px;">No need to worry about your future plans or ways to make your future safe. Make a insurance policy with us and we will make your life secured one.</p>
        </li>
        <li class="panel-bottom"></li>
      </ul>
    </div>
    <div class="panel"> <img src="images/letters.jpg" width="180" height="180" alt=""/>
      <h1>CONSIGNMENT</h1>
      <h2>&nbsp;</h2>
      <ul>
        <li class="panel-top"></li>
        <li class="panel-middle">
         <p style="font-size:24px;">Still love to send letters? We do offer even letters facility i.e Ordinary letters, Registred and Speed post. Just select a appropriated one and we will help you out.</p>
        </li>
        <li class="panel-bottom"></li>
      </ul>
    </div>
    <div class="clear"></div>
  </div>
</div>