<?php
include("header.php");
?>
  <div class="header">
    <h1>To make your life easier</h1>
    <h2>In your service for 24/7</h2>
    <div class="header-button"><a href="about.php">More Info</a> </div>
  </div>
  
</div>
<?php
include("banner.php");
?>

<?php
include("footer.php");
?>