<?php
include("header.php");
?>
3
  <div class="header">
    <h1>To make your life easier</h1>
    <h2>In your service for 24/7</h2>
    
  </div>
  
</div>

<div class="columns-container">
  <div class="columns-wrapper">
    <?php
	include("leftside.php");
	?>
    <div class="right-column">
      <div class="right-column-heading">
        <h1> <p style="font-size:24px;">                              
        <img src="images/cu.jpg" width="180" height="180" alt=""/>    
          <p style="font-size:24px;">          
          <p style="font-size:24px;">          
          <h1><p style="font-size:24px;">Got a query, want to give us some feedback or make a complaint about one of our services?Here's how you can find answers and get in touch with us. </p></h1>                                                                           
        <p>&nbsp;</p>
        <h1>
          <p style="font-size:24px;"><strong><u>Customer Service</u></strong>: 1811 218 9898</p></h1>
        <p style="font-size:24px;">&nbsp;</p>
        <h1>
          <p style="font-size:24px;"><strong><u>Website</u></strong>:  www.postoffice.com</p></h1>
        <p style="font-size:24px;">&nbsp;</p>
        <h1><p style="font-size:24px;"><u><strong>Contact us on:</strong></u><u><strong></strong></u><strong></strong></p></h1>
        <p>&nbsp;</p>
        <h1> <p style="font-size:24px;">Ph(9972853368)   </p></h1>
        <p style="font-size:24px;">&nbsp;</p>
        <h1><p style="font-size:24px;"><strong><u>Mail us @</u></strong> : </p>
          <p style="font-size:24px;">&nbsp;</p>
        </h1>
        <h1> <p style="font-size:24px;">studentprojectguide.com@gmail.com</p></h1>
        <p style="font-size:24px;">&nbsp;</p>
        <h1><p style="font-size:24px;"><strong><u>Address:</u></strong></p>
          <p style="font-size:24px;">&nbsp;</p>
        </h1>
         <h1><p style="font-size:24px;">Kamarottu Estate</p>
        <p style="font-size:24px;">Post Office</p>
        <p style="font-size:24px;">3rd Cross, Main Road</p>
        <p style="font-size:24px;">Bangalore-675001</p></h1>
        <p style="font-size:24px;">&nbsp;</p>
        <p>&nbsp;	  </p>
        <p>&nbsp;</p>
      </div>
      <div class="right-column-content">
        <h1>&nbsp;</h1>
      </div>
      <div class="right-column-content"></div>
      <div class="right-column-content noborder">
        <h1>&nbsp;</h1>
      </div>
    </div>
  </div>
</div>
<?php
include("footer.php");
?>