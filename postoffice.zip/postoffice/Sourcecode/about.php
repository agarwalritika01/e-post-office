<?php
include("header.php");
?>
  <div class="header">
    <h1>To make your life easier</h1>
    <h2>In your service for 24/7</h2>
   
  </div>
  
</div>

<div class="columns-container">
  <div class="columns-wrapper">
    <?php
	include("leftside.php");
	?>
    <div class="right-column">
      <div class="right-column-heading">
        <h1><p style="font-size: 36px;"><u><strong>About:<img src="images/postoffice.png" width="400" height="200" alt=""/></strong></u></p></h1>
      <p>&nbsp;</p>
     <h1> <p style="font-size:24px;">&nbsp;</p>
       <p style="font-size:24px;"><b>A <u>post office</u>&nbsp;is a customer  service&nbsp;facility forming part of a national postal-system.&nbsp;Post  offices offer mail-related services such as acceptance of&nbsp;letters,  provision of post office boxes. In addition, many post offices offer additional  services: providing and accepting money orders, payment of bills, Insurance and  other postal services.</b></p>
     </h1>
      </div>
      <div class="right-column-content">
        <h1>
        <p style="font-size:24px;"><u><strong>Number of Post Offices all over India:</strong></u></h1>
        <p>&nbsp;</p>
     <h1> <p style="font-size:24px;"><b>As of 31 March 2011&nbsp;[update],  the Indian Postal Service had&nbsp;154,866  post offices, of which 139,040 (89.78 percent) were in rural areas and  15,826 (10.22 percent) in urban areas. It had&nbsp;25,464&nbsp;departmental Post Offices and&nbsp;129,402&nbsp;Extra-Departmental Branch Post  Offices.</b></p></h1>
</div>
      <div class="right-column-content">
        <h1><p style="font-size:24px;"><strong><u>Establishment</u>:</strong></h1>
        <p>&nbsp;</p>
      <h1> <p style="font-size:24px;"><b>In&nbsp;June  1788, the ninth state ratified the Constitution, which gave Congress the  power &ldquo;To establish Post Offices and post Roads&rdquo; in Article I, Section 8. A  year later, the Act of&nbsp;September  22, 1789&nbsp;(1 Stat. 70),  continued the Post Office and made the Postmaster General subject to the  direction of the President</b></p></h1>
        <p>&nbsp;</p>
      </div>
      <div class="right-column-content noborder"></div>
    </div>
  </div>
</div>
<?php
include("footer.php");
?>