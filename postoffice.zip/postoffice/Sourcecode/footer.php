<div class="footer">
  <div class="copy-rights">Copyright (c) 2023. Designed by Rajat Vyas, Rashika joshi, Ritika Agarwal, Sakshi Khandelwal</div>
</div>
</body>
</html>
